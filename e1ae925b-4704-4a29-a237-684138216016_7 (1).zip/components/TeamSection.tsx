
'use client';

export default function TeamSection() {
  const team = [
    {
      name: "Ahmed Hassan",
      role: "Founder & Education Director",
      bio: "Passionate educator with 5+ years in tech training. Leads our YouTube content strategy and curriculum development.",
      image: "https://readdy.ai/api/search-image?query=Professional%20young%20male%20educator%20and%20tech%20entrepreneur%2C%20friendly%20smile%2C%20modern%20business%20casual%20attire%2C%20clean%20professional%20headshot%20with%20blue%20background%2C%20inspiring%20leadership%20presence&width=300&height=300&seq=founder-ahmed&orientation=squarish",
      social: {
        linkedin: "https://linkedin.com/in/ahmed-hassan-techzameen",
        twitter: "https://twitter.com/ahmed_techzameen"
      }
    },
    {
      name: "Sara Khan",
      role: "Content & Community Manager", 
      bio: "Expert in digital content creation and community building. Manages our social platforms and student engagement programs.",
      image: "https://readdy.ai/api/search-image?query=Professional%20young%20female%20content%20manager%20and%20community%20builder%2C%20confident%20smile%2C%20modern%20business%20attire%2C%20clean%20professional%20headshot%20with%20blue%20background%2C%20approachable%20and%20friendly%20demeanor&width=300&height=300&seq=manager-sara&orientation=squarish",
      social: {
        linkedin: "https://linkedin.com/in/sara-khan-techzameen",
        facebook: "https://facebook.com/sara.khan.techzameen"
      }
    },
    {
      name: "Ali Raza",
      role: "Technical Lead & Mentor",
      bio: "Full-stack developer and mentor with expertise in modern web technologies. Guides our technical internship programs.",
      image: "https://readdy.ai/api/search-image?query=Professional%20young%20male%20software%20developer%20and%20technical%20mentor%2C%20confident%20expression%2C%20casual%20tech%20professional%20attire%2C%20clean%20professional%20headshot%20with%20blue%20background%2C%20technical%20expertise%20presence&width=300&height=300&seq=tech-lead-ali&orientation=squarish",
      social: {
        linkedin: "https://linkedin.com/in/ali-raza-techzameen",
        github: "https://github.com/ali-raza-techzameen"
      }
    }
  ];

  const stats = [
    { number: "15K+", label: "Students Educated", icon: "ri-graduation-cap-line" },
    { number: "200+", label: "Interns Hired", icon: "ri-team-line" },
    { number: "50+", label: "YouTube Tutorials", icon: "ri-play-circle-line" },
    { number: "3K+", label: "Community Members", icon: "ri-group-line" }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">Meet Our Team</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our dedicated team of educators, mentors, and tech professionals work together to create the best learning experience for students.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {team.map((member, index) => (
            <div key={index} className="bg-gradient-to-br from-blue-50 to-white rounded-xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow duration-300">
              <div className="relative mb-6">
                <img 
                  src={member.image} 
                  alt={member.name}
                  className="w-32 h-32 rounded-full mx-auto object-cover shadow-lg"
                />
                <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
                  Team
                </div>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-2">{member.name}</h3>
              <p className="text-blue-600 font-semibold mb-4">{member.role}</p>
              <p className="text-gray-600 text-sm leading-relaxed mb-6">{member.bio}</p>
              
              <div className="flex justify-center gap-3">
                {Object.entries(member.social).map(([platform, url], socialIndex) => {
                  const iconMap: { [key: string]: string } = {
                    linkedin: 'ri-linkedin-fill',
                    twitter: 'ri-twitter-fill', 
                    facebook: 'ri-facebook-fill',
                    github: 'ri-github-fill'
                  };
                  
                  const colorMap: { [key: string]: string } = {
                    linkedin: 'bg-blue-600 hover:bg-blue-700',
                    twitter: 'bg-blue-400 hover:bg-blue-500',
                    facebook: 'bg-blue-800 hover:bg-blue-900',
                    github: 'bg-gray-800 hover:bg-gray-900'
                  };
                  
                  return (
                    <a 
                      key={socialIndex}
                      href={url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`w-10 h-10 flex items-center justify-center ${colorMap[platform]} rounded-full transition-colors cursor-pointer`}
                    >
                      <i className={`${iconMap[platform]} text-sm text-white`}></i>
                    </a>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-br from-gray-900 to-blue-900 text-white rounded-2xl p-12">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">Our Impact in Numbers</h3>
            <p className="text-blue-200 text-lg">
              See how Tech Zameen is making a difference in the lives of students and aspiring tech professionals.
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 flex items-center justify-center bg-blue-600 rounded-full mx-auto mb-4">
                  <i className={`${stat.icon} text-2xl text-white`}></i>
                </div>
                <div className="text-3xl font-bold text-blue-300 mb-2">{stat.number}</div>
                <div className="text-blue-200">{stat.label}</div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <h4 className="text-2xl font-bold mb-4">Want to Join Our Mission?</h4>
            <p className="text-blue-200 mb-6">
              We're always looking for passionate individuals to join our team as interns and help us educate the next generation.
            </p>
            <a href="/contact" className="bg-blue-600 text-white px-8 py-4 rounded-full font-semibold hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
              Apply for Internship
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
