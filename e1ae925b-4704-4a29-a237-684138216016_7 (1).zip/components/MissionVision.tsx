
'use client';

export default function MissionVision() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-8">Our Story</h2>
            <div className="space-y-6 text-gray-600 leading-relaxed">
              <p className="text-lg">
                Tech Zameen was born from a simple yet powerful vision: to bridge the gap between learning and real-world tech experience. 
                As a youth-driven platform, we understand the challenges students face when trying to transition from theoretical knowledge to practical skills.
              </p>
              <p className="text-lg">
                Our journey began with recognizing that traditional education often leaves a void between what students learn in classrooms 
                and what the industry actually needs. We decided to fill this gap by creating a comprehensive ecosystem that combines 
                quality education through YouTube tutorials with real internship opportunities.
              </p>
              <p className="text-lg">
                Today, Tech Zameen serves thousands of students worldwide, helping them develop digital skills, gain practical experience, 
                and build successful tech careers. We focus exclusively on learning, internships, and digital skill development.
              </p>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://readdy.ai/api/search-image?query=Young%20diverse%20team%20of%20students%20and%20professionals%20working%20together%20on%20technology%20projects%2C%20collaborative%20learning%20environment%2C%20modern%20office%20space%20with%20laptops%20and%20educational%20materials%2C%20inspiring%20teamwork%20atmosphere%20with%20blue%20and%20white%20color%20scheme&width=600&height=500&seq=our-story&orientation=landscape" 
              alt="Our Story"
              className="w-full h-auto rounded-xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -right-6 bg-blue-600 text-white p-6 rounded-xl shadow-lg">
              <div className="text-center">
                <div className="text-2xl font-bold">15K+</div>
                <div className="text-sm">Students Educated</div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-20 grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-xl">
            <div className="w-16 h-16 flex items-center justify-center bg-blue-600 rounded-full mb-6">
              <i className="ri-target-line text-2xl text-white"></i>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
            <p className="text-gray-700 leading-relaxed">
              To democratize technology education and create pathways for students to gain real-world experience through 
              quality learning resources and meaningful internship opportunities. We believe every student deserves access 
              to practical tech education that prepares them for successful careers.
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-8 rounded-xl">
            <div className="w-16 h-16 flex items-center justify-center bg-purple-600 rounded-full mb-6">
              <i className="ri-eye-line text-2xl text-white"></i>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Vision</h3>
            <p className="text-gray-700 leading-relaxed">
              To become the leading platform where students transform from learners to skilled professionals through 
              comprehensive education and hands-on experience. We envision a world where the gap between education 
              and industry requirements no longer exists.
            </p>
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-green-50 to-green-100 p-8 rounded-xl max-w-4xl mx-auto border-l-4 border-green-500">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Currently Hiring Interns Only</h3>
            <p className="text-lg text-gray-700 mb-6">
              We are focused on nurturing fresh talent and providing opportunities for students to gain real-world experience. 
              Our internship programs cover content creation, tech support, digital marketing, web development, UI/UX design, and community management.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="/contact" className="bg-green-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap">
                Apply for Internship
              </a>
              <a href="https://youtube.com/@techzameen" target="_blank" rel="noopener noreferrer" className="border-2 border-green-600 text-green-600 px-8 py-3 rounded-full font-semibold hover:bg-green-600 hover:text-white transition-colors cursor-pointer whitespace-nowrap">
                Watch Our Tutorials
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
