
'use client';

export default function ExpertiseSection() {
  const expertise = [
    {
      title: "YouTube Education",
      description: "Creating comprehensive tutorials and educational content that makes complex tech concepts accessible to everyone.",
      icon: "ri-youtube-line",
      color: "bg-red-500",
      skills: ["Video Production", "Educational Content", "Tutorial Design", "Student Engagement"]
    },
    {
      title: "Internship Programs",
      description: "Designing structured internship experiences that provide real-world skills and career preparation.",
      icon: "ri-briefcase-line", 
      color: "bg-blue-500",
      skills: ["Mentorship", "Project Management", "Career Development", "Skill Assessment"]
    },
    {
      title: "Digital Skills Training",
      description: "Teaching practical digital skills including web development, programming, and digital marketing.",
      icon: "ri-computer-line",
      color: "bg-green-500", 
      skills: ["Web Development", "Programming", "Digital Marketing", "UI/UX Design"]
    },
    {
      title: "Community Building",
      description: "Fostering a supportive learning community through social platforms and interactive engagement.",
      icon: "ri-group-line",
      color: "bg-purple-500",
      skills: ["Community Management", "Social Media", "Event Organization", "Student Support"]
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Expertise Areas</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We specialize in education, internships, and digital skills development, creating a comprehensive learning ecosystem for students.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {expertise.map((item, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-start gap-4">
                <div className={`w-14 h-14 flex items-center justify-center ${item.color} rounded-xl flex-shrink-0`}>
                  <i className={`${item.icon} text-2xl text-white`}></i>
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{item.title}</h3>
                  <p className="text-gray-600 mb-4">{item.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {item.skills.map((skill, skillIndex) => (
                      <span key={skillIndex} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-12 rounded-2xl max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold mb-4">Ready to Learn and Grow?</h3>
            <p className="text-xl text-blue-100 mb-8">
              Join our platform and start your journey from learning to professional success through our comprehensive programs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="/contact" className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap">
                Apply for Internship
              </a>
              <a href="https://youtube.com/@techzameen" target="_blank" rel="noopener noreferrer" className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-colors cursor-pointer whitespace-nowrap">
                Start Learning
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
