'use client';

import Link from 'next/link';

export default function ServicesSection() {
  const services = [
    {
      icon: 'ri-smartphone-line',
      title: 'Mobile App Development',
      description: 'Custom Flutter applications that deliver exceptional performance across iOS and Android platforms with native-like user experiences.',
      features: ['Cross-Platform Compatibility', 'Native Performance', 'Rapid Development', 'Cost-Effective Solutions']
    },
    {
      icon: 'ri-palette-line',
      title: 'UI/UX Design',
      description: 'Stunning, intuitive interfaces designed to engage users and provide seamless interactions that drive business growth.',
      features: ['User-Centered Design', 'Responsive Layouts', 'Interactive Prototypes', 'Brand Consistency']
    },
    {
      icon: 'ri-apps-2-line',
      title: 'Cross-Platform Solutions',
      description: 'Comprehensive development strategies that maximize reach while minimizing development time and maintenance costs.',
      features: ['Single Codebase', 'Multi-Platform Deployment', 'Consistent User Experience', 'Easy Maintenance']
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Our Flutter Development Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We specialize in creating powerful, scalable, and beautiful mobile applications using Flutter technology. 
            Our comprehensive services cover every aspect of your app development journey.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="group bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-blue-200 p-8">
              <div className="w-16 h-16 flex items-center justify-center bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg mb-6 group-hover:scale-110 transition-transform duration-300">
                <i className={`${service.icon} text-2xl text-white`}></i>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors">
                {service.title}
              </h3>
              
              <p className="text-gray-600 mb-6 leading-relaxed">
                {service.description}
              </p>
              
              <ul className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                    <div className="w-4 h-4 flex items-center justify-center mr-3">
                      <i className="ri-check-line text-blue-500 font-semibold"></i>
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <Link href="/contact" className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-8 py-4 rounded-full font-semibold hover:from-blue-700 hover:to-blue-800 transition-all duration-300 shadow-lg hover:shadow-xl cursor-pointer whitespace-nowrap">
            Start Your Project Today
          </Link>
        </div>
      </div>
    </section>
  );
}
