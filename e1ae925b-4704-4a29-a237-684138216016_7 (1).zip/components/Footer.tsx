
'use client';

import Link from 'next/link';

export default function Footer() {
  const socialLinks = [
    {
      name: 'YouTube',
      icon: 'ri-youtube-fill',
      url: 'https://youtube.com/@techzameen',
      color: 'bg-red-600 hover:bg-red-700'
    },
    {
      name: 'Facebook', 
      icon: 'ri-facebook-fill',
      url: 'https://www.facebook.com/people/Tech-Zameen/61579112272085/',
      color: 'bg-blue-600 hover:bg-blue-700'
    },
    {
      name: 'WhatsApp',
      icon: 'ri-whatsapp-fill', 
      url: 'https://chat.whatsapp.com/EujvO46GoHqJNKNWURB0Pg?mode=ac_t',
      color: 'bg-green-600 hover:bg-green-700'
    },
    {
      name: 'Fiverr',
      icon: 'ri-briefcase-fill',
      url: 'https://www.fiverr.com/s/YRXZ62z',
      color: 'bg-emerald-600 hover:bg-emerald-700'
    }
  ];

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <h3 className="text-2xl font-bold text-blue-400 font-[\'Pacifico\'] mb-4">
              Tech Zameen
            </h3>
            <p className="text-gray-300 mb-6 max-w-md">
              Empowering learners and hiring future talent. Your gateway to technology education and career opportunities through YouTube tutorials, internships, and community support.
            </p>
            <div className="flex gap-3">
              {socialLinks.map((social, index) => (
                <a 
                  key={index}
                  href={social.url} 
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-10 h-10 flex items-center justify-center ${social.color} rounded-full transition-colors cursor-pointer`}
                >
                  <i className={`${social.icon} text-lg`}></i>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Our Focus</h4>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li>YouTube Education</li>
              <li>Internship Programs</li>
              <li>Digital Skills Training</li>
              <li>Community Building</li>
              <li>Career Development</li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-300 hover:text-white transition-colors cursor-pointer text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-300 hover:text-white transition-colors cursor-pointer text-sm">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-300 hover:text-white transition-colors cursor-pointer text-sm">
                  Contact & Apply
                </Link>
              </li>
              <li>
                <a href="https://youtube.com/@techzameen" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-white transition-colors cursor-pointer text-sm">
                  YouTube Tutorials
                </a>
              </li>
              <li>
                <a href="https://www.fiverr.com/s/YRXZ62z" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-white transition-colors cursor-pointer text-sm">
                  Hire on Fiverr
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">
              2024 Tech Zameen. All rights reserved. Domain: techzameen.it
            </p>
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <span>Currently Hiring Interns Only</span>
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
