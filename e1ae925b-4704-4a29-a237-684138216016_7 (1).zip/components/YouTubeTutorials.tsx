'use client';

export default function YouTubeTutorials() {
  const tutorials = [
    {
      title: "Complete Web Development Bootcamp",
      description: "Learn HTML, CSS, JavaScript, and React from scratch with hands-on projects.",
      thumbnail: "https://readdy.ai/api/search-image?query=Web%20development%20tutorial%20thumbnail%20with%20HTML%20CSS%20JavaScript%20code%20on%20computer%20screen%2C%20modern%20programming%20tutorial%20design%2C%20educational%20content%20thumbnail%20with%20colorful%20coding%20interface&width=400&height=225&seq=web-dev-tutorial&orientation=landscape",
      duration: "12:45",
      views: "25K"
    },
    {
      title: "Python for Beginners - Full Course",
      description: "Master Python programming with real-world examples and practice exercises.",
      thumbnail: "https://readdy.ai/api/search-image?query=Python%20programming%20tutorial%20thumbnail%20showing%20Python%20code%20and%20snake%20logo%2C%20educational%20programming%20content%20with%20clean%20modern%20design%2C%20beginner%20friendly%20coding%20tutorial%20interface&width=400&height=225&seq=python-tutorial&orientation=landscape",
      duration: "18:30",
      views: "42K"
    },
    {
      title: "Mobile App Development with Flutter",
      description: "Build beautiful cross-platform mobile apps using Flutter framework.",
      thumbnail: "https://readdy.ai/api/search-image?query=Flutter%20mobile%20app%20development%20tutorial%20thumbnail%20with%20smartphone%20app%20interfaces%2C%20Flutter%20logo%20and%20Dart%20code%2C%20modern%20app%20development%20educational%20content%20design&width=400&height=225&seq=flutter-tutorial&orientation=landscape",
      duration: "15:20",
      views: "18K"
    },
    {
      title: "Digital Marketing Essentials",
      description: "Learn SEO, social media marketing, and content creation strategies.",
      thumbnail: "https://readdy.ai/api/search-image?query=Digital%20marketing%20tutorial%20thumbnail%20with%20social%20media%20icons%2C%20analytics%20charts%20and%20marketing%20graphics%2C%20modern%20educational%20content%20design%20for%20marketing%20course&width=400&height=225&seq=marketing-tutorial&orientation=landscape",
      duration: "10:15",
      views: "31K"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Learn Through Our YouTube Tutorials
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Access free, high-quality educational content designed to help you master the latest technologies and digital skills.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {tutorials.map((tutorial, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden group cursor-pointer">
              <div className="relative">
                <img 
                  src={tutorial.thumbnail} 
                  alt={tutorial.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                  {tutorial.duration}
                </div>
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center">
                  <div className="w-16 h-16 flex items-center justify-center bg-red-600 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <i className="ri-play-fill text-2xl text-white"></i>
                  </div>
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-bold text-lg text-gray-900 mb-2 line-clamp-2">
                  {tutorial.title}
                </h3>
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                  {tutorial.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">{tutorial.views} views</span>
                  <div className="w-6 h-6 flex items-center justify-center bg-red-600 rounded-full">
                    <i className="ri-youtube-fill text-sm text-white"></i>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <a 
            href="https://youtube.com/@techzameen" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-red-600 text-white px-8 py-4 rounded-full font-semibold hover:bg-red-700 transition-colors cursor-pointer whitespace-nowrap"
          >
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-youtube-fill text-lg"></i>
            </div>
            Subscribe to Our Channel
          </a>
        </div>
      </div>
    </section>
  );
}