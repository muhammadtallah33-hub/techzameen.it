
'use client';

import { useState } from 'react';

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Create mailto link with form data
    const subject = encodeURIComponent(`Contact from ${formData.name} - Tech Zameen`);
    const body = encodeURIComponent(
      `Name: ${formData.name}\\nEmail: ${formData.email}\\n\\nMessage:\\n${formData.message}`
    );
    const mailtoUrl = `mailto:muhammadtallah33@gmail.com?subject=${subject}&body=${body}`;

    // Open email client
    window.open(mailtoUrl);

    // Reset form
    setFormData({ name: '', email: '', message: '' });

    // Show success message
    alert('Thank you! Your email client will open with the message ready to send.');
  };

  return (
    <div>
      <h2 className="text-3xl font-bold text-gray-900 mb-8">Send Us a Message</h2>
      <p className="text-gray-600 mb-8">
        Interested in our internship opportunities or have questions about our platform? Get in touch with us!
      </p>

      <form id="tech-zameen-contact" onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
            Full Name *
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
            placeholder="Enter your full name"
            required
          />
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
            Email Address *
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
            placeholder="Enter your email address"
            required
          />
        </div>

        <div>
          <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
            Message * 
          </label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleInputChange}
            rows={6}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm resize-none"
            placeholder="Tell us about your interest in internships, questions about our platform, or how we can help you"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-blue-800 transition-all duration-300 cursor-pointer whitespace-nowrap"
        >
          Send Message
        </button>

      </form>

      <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
        <div className="flex items-start gap-3">
          <div className="w-5 h-5 flex items-center justify-center text-yellow-600 mt-0.5">
            <i className="ri-information-line text-sm"></i>
          </div>
          <div>
            <h4 className="font-semibold text-yellow-800 mb-1">Quick Application Tip</h4>
            <p className="text-yellow-700 text-sm">
              For internship applications, please mention your area of interest (Content Creation, Tech Support, Digital Marketing, Web Development, UI/UX Design, or Community Management) in your message.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
