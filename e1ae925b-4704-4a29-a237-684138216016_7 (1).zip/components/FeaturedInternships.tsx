
'use client';

export default function FeaturedInternships() {
  const internships = [
    {
      title: "Content Creator Intern",
      department: "Digital Marketing",
      type: "Remote",
      duration: "3 months",
      description: "Create engaging educational content for our YouTube channel and social media platforms. Perfect for creative minds passionate about tech education.",
      requirements: ["Basic video editing skills", "Creative writing", "Social media knowledge", "Tech enthusiasm"],
      icon: "ri-video-line"
    },
    {
      title: "Tech Support Intern",
      department: "Technical",
      type: "Remote",
      duration: "4 months", 
      description: "Help students with technical issues, manage our learning platform, and provide customer support through various channels.",
      requirements: ["Problem-solving skills", "Basic programming knowledge", "Communication skills", "Patience with learners"],
      icon: "ri-customer-service-2-line"
    },
    {
      title: "Digital Marketing Intern",
      department: "Marketing",
      type: "Remote",
      duration: "3 months",
      description: "Develop marketing strategies, manage social media campaigns, and help grow our online community of learners.",
      requirements: ["Social media expertise", "Marketing fundamentals", "Analytics knowledge", "Creative thinking"],
      icon: "ri-megaphone-line"
    },
    {
      title: "Web Development Intern",
      department: "Development",
      type: "Remote", 
      duration: "6 months",
      description: "Work on improving our platform, build new features, and contribute to open-source educational tools.",
      requirements: ["HTML/CSS/JavaScript", "React knowledge", "Git/GitHub", "Learning mindset"],
      icon: "ri-code-line"
    },
    {
      title: "UI/UX Design Intern",
      department: "Design",
      type: "Remote",
      duration: "4 months",
      description: "Design user-friendly interfaces for our learning platform and create visual content for educational materials.",
      requirements: ["Design tools (Figma/Adobe)", "UI/UX principles", "User research", "Creative portfolio"],
      icon: "ri-palette-line"
    },
    {
      title: "Community Manager Intern",
      department: "Community",
      type: "Remote",
      duration: "3 months",
      description: "Manage our WhatsApp groups, engage with learners, organize virtual events, and build our learning community.",
      requirements: ["Community building", "Event management", "Communication skills", "Tech passion"],
      icon: "ri-group-line"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Featured Internship Opportunities
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Join Tech Zameen as an intern and gain real-world experience while helping thousands of students learn technology skills.
          </p>
          <div className="inline-flex items-center gap-2 bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-semibold">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            We are currently hiring interns only
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {internships.map((internship, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 p-6 border border-gray-100 group">
              <div className="flex items-center justify-between mb-4">
                <div className={`${internship.icon} text-2xl text-blue-600 w-12 h-12 flex items-center justify-center bg-blue-100 rounded-lg group-hover:bg-blue-200 transition-colors`}>
                </div>
                <div className="text-right">
                  <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-semibold">
                    {internship.type}
                  </span>
                </div>
              </div>

              <h3 className="font-bold text-xl text-gray-900 mb-2">
                {internship.title}
              </h3>
              
              <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
                <span className="flex items-center gap-1">
                  <i className="ri-building-line text-sm"></i>
                  {internship.department}
                </span>
                <span className="flex items-center gap-1">
                  <i className="ri-time-line text-sm"></i>
                  {internship.duration}
                </span>
              </div>

              <p className="text-gray-600 mb-4 line-clamp-3">
                {internship.description}
              </p>

              <div className="mb-6">
                <h4 className="font-semibold text-sm text-gray-900 mb-2">Requirements:</h4>
                <ul className="space-y-1">
                  {internship.requirements.slice(0, 2).map((req, reqIndex) => (
                    <li key={reqIndex} className="text-sm text-gray-600 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                      {req}
                    </li>
                  ))}
                  {internship.requirements.length > 2 && (
                    <li className="text-sm text-gray-500">
                      +{internship.requirements.length - 2} more requirements
                    </li>
                  )}
                </ul>
              </div>

              <button className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-blue-800 transition-all duration-300 cursor-pointer whitespace-nowrap">
                Apply Now
              </button>
            </div>
          ))}
        </div>

        <div className="text-center">
          <div className="bg-white rounded-xl shadow-lg p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Ready to Start Your Tech Journey?</h3>
            <p className="text-gray-600 mb-6">
              Join our internship program and gain hands-on experience while contributing to the tech education community.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="/contact" 
                className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                Apply for Internship
              </a>
              <a 
                href="https://chat.whatsapp.com/EujvO46GoHqJNKNWURB0Pg?mode=ac_t" 
                target="_blank" 
                rel="noopener noreferrer"
                className="border-2 border-green-500 text-green-600 px-8 py-3 rounded-full font-semibold hover:bg-green-500 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
              >
                Join WhatsApp Group
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
