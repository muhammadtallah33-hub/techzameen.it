
'use client';

export default function ContactInfo() {
  const contactMethods = [
    {
      title: "Email Us",
      description: "Send us your inquiries about internships or general questions. We respond within 24 hours.",
      icon: "ri-mail-line",
      color: "from-blue-50 to-blue-100",
      iconColor: "bg-blue-600",
      contact: "muhammadtallah33@gmail.com",
      link: "mailto:muhammadtallah33@gmail.com",
      linkColor: "text-blue-600 hover:text-blue-700"
    },
    {
      title: "Join WhatsApp Group", 
      description: "Connect with our learning community, ask questions, and get instant support from peers and mentors.",
      icon: "ri-whatsapp-line",
      color: "from-green-50 to-green-100", 
      iconColor: "bg-green-600",
      contact: "Tech Zameen Community",
      link: "https://chat.whatsapp.com/EujvO46GoHqJNKNWURB0Pg?mode=ac_t",
      linkColor: "text-green-600 hover:text-green-700"
    },
    {
      title: "Availability",
      description: "We operate fully online and are available around the clock to support your learning journey.",
      icon: "ri-global-line",
      color: "from-purple-50 to-purple-100",
      iconColor: "bg-purple-600", 
      contact: "Available 24/7 Online",
      link: null,
      linkColor: "text-purple-600 font-medium"
    }
  ];

  const socialLinks = [
    {
      name: 'YouTube',
      icon: 'ri-youtube-fill',
      url: 'https://youtube.com/@techzameen',
      color: 'bg-red-600 hover:bg-red-700',
      followers: '15K+ subscribers'
    },
    {
      name: 'Facebook',
      icon: 'ri-facebook-fill', 
      url: 'https://www.facebook.com/people/Tech-Zameen/61579112272085/',
      color: 'bg-blue-600 hover:bg-blue-700',
      followers: '8K+ followers'
    },
    {
      name: 'WhatsApp Group',
      icon: 'ri-whatsapp-fill',
      url: 'https://chat.whatsapp.com/EujvO46GoHqJNKNWURB0Pg?mode=ac_t',
      color: 'bg-green-600 hover:bg-green-700',
      followers: '2K+ members'
    }
  ];

  return (
    <div>
      <h2 className="text-3xl font-bold text-gray-900 mb-8">Get In Touch</h2>
      
      <div className="space-y-6 mb-12">
        {contactMethods.map((method, index) => (
          <div key={index} className={`bg-gradient-to-br ${method.color} p-6 rounded-xl`}>
            <div className={`w-12 h-12 flex items-center justify-center ${method.iconColor} rounded-lg mb-4`}>
              <i className={`${method.icon} text-xl text-white`}></i>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{method.title}</h3>
            <p className="text-gray-600 mb-3">{method.description}</p>
            {method.link ? (
              <a 
                href={method.link} 
                target={method.link.startsWith('http') ? '_blank' : undefined}
                rel={method.link.startsWith('http') ? 'noopener noreferrer' : undefined}
                className={`${method.linkColor} font-medium cursor-pointer`}
              >
                {method.contact}
              </a>
            ) : (
              <span className={method.linkColor}>{method.contact}</span>
            )}
          </div>
        ))}
      </div>

      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Follow Our Journey</h3>
        <p className="text-gray-600 mb-6">
          Stay connected with our growing community and never miss new tutorials, internship openings, or community events.
        </p>
        
        <div className="space-y-3">
          {socialLinks.map((social, index) => (
            <a
              key={index}
              href={social.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 flex items-center justify-center ${social.color} rounded-full transition-colors`}>
                  <i className={`${social.icon} text-lg text-white`}></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">{social.name}</div>
                  <div className="text-sm text-gray-600">{social.followers}</div>
                </div>
              </div>
              <div className="w-5 h-5 flex items-center justify-center text-gray-400">
                <i className="ri-external-link-line text-sm"></i>
              </div>
            </a>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-br from-gray-900 to-blue-900 text-white p-6 rounded-xl">
        <h3 className="text-lg font-semibold mb-3">Ready to Start Your Tech Journey?</h3>
        <p className="text-blue-100 mb-4 text-sm">
          Join thousands of students who are already learning and growing with Tech Zameen. Apply for an internship or start learning with our free tutorials.
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <a 
            href="https://youtube.com/@techzameen" 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-red-600 text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-red-700 transition-colors cursor-pointer text-center whitespace-nowrap"
          >
            Watch Tutorials
          </a>
          <a 
            href="https://chat.whatsapp.com/EujvO46GoHqJNKNWURB0Pg?mode=ac_t" 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-green-600 text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-green-700 transition-colors cursor-pointer text-center whitespace-nowrap"
          >
            Join Community
          </a>
        </div>
      </div>
    </div>
  );
}
