
'use client';

export default function SocialSection() {
  const socialPlatforms = [
    {
      name: "YouTube",
      description: "Subscribe to our channel for free tutorials on web development, programming, and digital skills.",
      followers: "15K+ Subscribers",
      icon: "ri-youtube-fill",
      color: "bg-red-600 hover:bg-red-700",
      url: "https://youtube.com/@techzameen",
      buttonText: "Subscribe Now"
    },
    {
      name: "Facebook",
      description: "Follow us for updates, tech news, and community discussions about learning and career opportunities.",
      followers: "8K+ Followers", 
      icon: "ri-facebook-fill",
      color: "bg-blue-600 hover:bg-blue-700",
      url: "https://www.facebook.com/people/Tech-Zameen/61579112272085/",
      buttonText: "Follow Page"
    },
    {
      name: "WhatsApp Group",
      description: "Join our active community of learners, share resources, ask questions, and network with peers.",
      followers: "2K+ Members",
      icon: "ri-whatsapp-fill", 
      color: "bg-green-600 hover:bg-green-700",
      url: "https://chat.whatsapp.com/EujvO46GoHqJNKNWURB0Pg?mode=ac_t",
      buttonText: "Join Group"
    },
    {
      name: "Fiverr Profile",
      description: "Hire us for professional Flutter development projects and get high-quality mobile applications.",
      followers: "Professional Services",
      icon: "ri-briefcase-fill", 
      color: "bg-emerald-600 hover:bg-emerald-700",
      url: "https://www.fiverr.com/s/YRXZ62z",
      buttonText: "Hire on Fiverr"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-blue-900 to-purple-900 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6">
            Connect With Our Community
          </h2>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Join thousands of learners and professionals across our social platforms. Get updates, participate in discussions, and hire us for projects.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {socialPlatforms.map((platform, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-sm rounded-xl p-8 text-center hover:bg-white/15 transition-all duration-300 border border-white/20">
              <div className={`w-16 h-16 flex items-center justify-center ${platform.color} rounded-full mx-auto mb-6 transition-colors`}>
                <i className={`${platform.icon} text-2xl text-white`}></i>
              </div>
              
              <h3 className="text-2xl font-bold mb-3">{platform.name}</h3>
              <p className="text-blue-100 mb-4">{platform.description}</p>
              
              <div className="mb-6">
                <span className="bg-white/20 text-white px-3 py-1 rounded-full text-sm font-semibold">
                  {platform.followers}
                </span>
              </div>

              <a 
                href={platform.url}
                target="_blank"
                rel="noopener noreferrer" 
                className={`inline-block ${platform.color} text-white px-6 py-3 rounded-full font-semibold transition-colors cursor-pointer whitespace-nowrap`}
              >
                {platform.buttonText}
              </a>
            </div>
          ))}
        </div>

        <div className="text-center">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 max-w-3xl mx-auto border border-white/20">
            <h3 className="text-2xl font-bold mb-4">Stay Connected & Hire Us</h3>
            <p className="text-blue-100 mb-6">
              Follow us on all platforms to never miss out on new tutorials, internship opportunities, and hire us for professional Flutter projects on Fiverr.
            </p>
            <div className="flex justify-center gap-4">
              {socialPlatforms.map((platform, index) => (
                <a 
                  key={index}
                  href={platform.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-12 h-12 flex items-center justify-center ${platform.color} rounded-full transition-colors cursor-pointer`}
                >
                  <i className={`${platform.icon} text-lg text-white`}></i>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
