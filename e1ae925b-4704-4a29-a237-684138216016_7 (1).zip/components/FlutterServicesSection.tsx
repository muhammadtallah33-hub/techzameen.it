'use client';

import Link from 'next/link';

export default function FlutterServicesSection() {
  const services = [
    {
      icon: 'ri-flutter-line',
      title: 'Flutter Development',
      description: 'Custom cross-platform mobile applications with native performance and beautiful user interfaces.',
      technologies: ['Flutter SDK', 'Dart Programming', 'State Management', 'Custom Widgets']
    },
    {
      icon: 'ri-palette-line',
      title: 'UI/UX Design',
      description: 'Intuitive and engaging designs that provide exceptional user experiences across all devices.',
      technologies: ['Material Design', 'Cupertino Design', 'Custom Animations', 'Responsive Layouts']
    },
    {
      icon: 'ri-firebase-line',
      title: 'Firebase Integration',
      description: 'Seamless backend services including authentication, real-time databases, and cloud storage.',
      technologies: ['Firebase Auth', 'Firestore', 'Cloud Storage', 'Push Notifications']
    },
    {
      icon: 'ri-api-line',
      title: 'API Integration',
      description: 'Connect your Flutter apps with REST APIs, GraphQL, and third-party services effortlessly.',
      technologies: ['REST APIs', 'GraphQL', 'WebSocket', 'Third-party SDKs']
    },
    {
      icon: 'ri-rocket-line',
      title: 'App Deployment',
      description: 'Complete app store deployment and continuous integration for smooth project delivery.',
      technologies: ['Play Store', 'App Store', 'CI/CD', 'Version Control']
    },
    {
      icon: 'ri-tools-line',
      title: 'Maintenance & Support',
      description: 'Ongoing support, updates, and performance optimization for your Flutter applications.',
      technologies: ['Bug Fixes', 'Performance Tuning', 'Feature Updates', 'Technical Support']
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Flutter Project Services
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto">
            We take on various Flutter projects, from simple mobile apps to complex enterprise solutions. 
            Our comprehensive expertise covers the entire development lifecycle, ensuring your project succeeds from concept to deployment.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {services.map((service, index) => (
            <div key={index} className="group bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-blue-200 p-6">
              <div className="w-14 h-14 flex items-center justify-center bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg mb-5 group-hover:scale-110 transition-transform duration-300">
                <i className={`${service.icon} text-2xl text-white`}></i>
              </div>
              
              <h3 className="text-lg font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                {service.title}
              </h3>
              
              <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                {service.description}
              </p>
              
              <div className="flex flex-wrap gap-2">
                {service.technologies.map((tech, techIndex) => (
                  <span key={techIndex} className="bg-blue-50 text-blue-600 px-2 py-1 rounded-md text-xs font-medium">
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-center text-white">
          <h3 className="text-2xl font-bold mb-4">Ready to Start Your Flutter Project?</h3>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Whether you need a simple app or a complex enterprise solution, our team of Flutter experts is ready to bring your vision to life. Let's discuss your project requirements and create something amazing together.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://www.fiverr.com/s/YRXZ62z" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
            >
              Hire on Fiverr
            </a>
            <Link href="/contact" className="border-2 border-white text-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-colors cursor-pointer whitespace-nowrap">
              Apply for Internship
            </Link>
            <a 
              href="https://chat.whatsapp.com/EujvO46GoHqJNKNWURB0Pg?mode=ac_t" 
              target="_blank" 
              rel="noopener noreferrer"
              className="border-2 border-white text-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-colors cursor-pointer whitespace-nowrap"
            >
              Join WhatsApp Group
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
