
'use client';

import Link from 'next/link';

export default function HeroSection() {
  return (
    <section 
      className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-white overflow-hidden"
      style={{
        backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20educational%20technology%20workspace%20with%20students%20learning%20coding%20and%20digital%20skills%2C%20young%20professionals%20working%20on%20computers%2C%20online%20learning%20environment%20with%20laptops%20and%20tablets%2C%20blue%20and%20white%20color%20scheme%2C%20inspiring%20educational%20atmosphere%2C%20bright%20modern%20classroom%20setting&width=1920&height=1080&seq=hero-education-bg&orientation=landscape')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      <div className="absolute inset-0 bg-blue-900/30"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Empowering Learners.
              <span className="text-blue-300 block">Hiring Future Talent.</span>
            </h1>
            <p className="text-xl text-blue-100 mb-8 leading-relaxed">
              Tech Zameen is your gateway to technology education and career opportunities. Learn through our YouTube tutorials, apply for internships, and join a community of aspiring tech professionals.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link href="/contact" className="bg-blue-600 text-white px-8 py-4 rounded-full font-semibold hover:bg-blue-700 transition-colors cursor-pointer text-center whitespace-nowrap">
                Apply for Internship
              </Link>
              <Link href="/about" className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-colors cursor-pointer text-center whitespace-nowrap">
                Learn More
              </Link>
            </div>
          </div>
          
          <div className="hidden lg:block">
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=Students%20learning%20technology%20skills%20on%20laptops%20and%20tablets%2C%20young%20people%20engaged%20in%20online%20education%2C%20digital%20learning%20platform%20interface%2C%20modern%20educational%20technology%20setup%20with%20coding%20tutorials%20on%20screens%2C%20inspiring%20learning%20environment&width=600&height=700&seq=hero-learning&orientation=portrait" 
                alt="Tech Education Platform"
                className="w-full h-auto rounded-lg shadow-2xl"
              />
              <div className="absolute -top-4 -left-4 w-20 h-20 bg-blue-500 rounded-full opacity-20 animate-pulse"></div>
              <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-blue-300 rounded-full opacity-30 animate-pulse delay-1000"></div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
}
