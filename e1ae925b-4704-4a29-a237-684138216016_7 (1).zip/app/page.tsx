'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from '@/components/HeroSection';
import FlutterServicesSection from '@/components/FlutterServicesSection';
import YouTubeTutorials from '@/components/YouTubeTutorials';
import FeaturedInternships from '@/components/FeaturedInternships';
import SocialSection from '@/components/SocialSection';

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <FlutterServicesSection />
        <YouTubeTutorials />
        <FeaturedInternships />
        <SocialSection />
      </main>
      <Footer />
    </div>
  );
}