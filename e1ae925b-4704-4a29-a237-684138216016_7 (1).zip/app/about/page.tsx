
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import MissionVision from '@/components/MissionVision';
import TeamSection from '@/components/TeamSection';
import ExpertiseSection from '@/components/ExpertiseSection';

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <section className="py-20 bg-gradient-to-br from-blue-50 to-white">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-5xl font-bold text-gray-900 mb-6">About Tech Zameen</h1>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto">
              Tech Zameen is a youth-driven platform built to bridge the gap between learning and real-world tech experience. 
              We are dedicated to empowering students through quality education and connecting them with meaningful internship opportunities.
            </p>
          </div>
        </section>
        <MissionVision />
        <ExpertiseSection />
        <TeamSection />
      </main>
      <Footer />
    </div>
  );
}
